//
//  ADC.h
//  MFM_rev6
//
//  Created by imashio on 12/3/14.
//
//

void ADC_init(void);