// Liquid Crystal Display Header File

void SoftSPI_LED_Init(void);
void SoftSPI_LED_TX(unsigned char);
void send_bits_595_LED(unsigned char);
