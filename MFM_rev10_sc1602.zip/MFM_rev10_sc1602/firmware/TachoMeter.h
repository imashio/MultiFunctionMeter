//
//  TachoMeter.h
//  MFM_rev5
//
//  Created by imashio on 11/17/14.
//
//

void TachoMeter_init(unsigned long int, unsigned long int);

unsigned long int TachoMeter();
