//
//  LEDarray.h
//  MFM_rev3
//
//  Created by imashio on 11/6/14.
//
//

//void LEDarray_init();
unsigned int LEDarray_init();

void LEDarray(unsigned int);