/*
 *  ExtInterrupt.h
 *  DefiLinkTap_rev0a
 *
 *  Created by Imashioya on 10/11/28.
 *  Copyright 2010 IMS corp. All rights reserved.
 *
 */

void ExtInterrupt_init(void);