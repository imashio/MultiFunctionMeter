//
//  FuelPumpDriver.h
//  MFM_rev6
//
//  Created by imashio on 11/26/14.
//
//

unsigned int FuelPumpDriver(unsigned long int,  float,      float, unsigned int);
                        //  rpm                 FuelPress   Boost  Maximum Drive Mode
