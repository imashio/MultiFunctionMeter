//
//  facemark.h
//  MFM_rev5
//
//  Created by imashio on 11/17/14.
//
//

void FaceMark_init(void);
void shobon(void);
void shakin(void);
void kuwa(void);

