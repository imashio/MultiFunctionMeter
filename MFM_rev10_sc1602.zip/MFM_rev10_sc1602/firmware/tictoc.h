//
//  tictoc.h
//  MFM_rev4
//
//  Created by imashio on 11/15/14.
//
//

void tictoc_init(unsigned int, unsigned int);

void tic(void);

unsigned long int toc(void);
